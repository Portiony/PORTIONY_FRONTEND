import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import character from "../../assets/LOGOMAIN.png"; // 실제 있는 파일명으로 수정
import back from "../../assets/chevron-left.svg";
import styles from "./Login.module.css";
import axios from "../../lib/axios";

function Login({ setIsLoggedIn }) {
  const [status, setStatus] = useState("init"); // init | form | done
  const [userEmail, setUserEmail] = useState("");
  const [userPassword, setUserPassword] = useState("");
  const navigate = useNavigate();

  const handleKakaoLogin = () => {
    const REST_API_KEY = "1905cc0f6daf870b0f4eb756b47ac06f";
    const REDIRECT_URI = "https://portiony.netlify.app/login/oauth/kakao";
    const kakaoAuthURL = `https://kauth.kakao.com/oauth/authorize?client_id=${REST_API_KEY}&redirect_uri=${REDIRECT_URI}&response_type=code`;
    window.location.href = kakaoAuthURL;
  };

  const handleFinalLogin = async () => {
    try {
      const response = await axios.post("/api/users/login", {
        email: userEmail,
        password: userPassword,
      });

      const { accessToken, refreshToken, userId } = response?.data ?? {};

      if (!accessToken || !refreshToken) {
        throw new Error("토큰이 응답되지 않았습니다.");
      }

      // 토큰 저장 (바깥으로 빼서 매번 새로 선언 안 하게)
      localStorage.setItem("access_token", accessToken);
      localStorage.setItem("refresh_token", refreshToken);
      localStorage.setItem("user_id", String(userId));

      setStatus("done");
    } catch (error) {
      console.error("로그인 실패:", error.response?.data || error.message);
      alert("이메일 또는 비밀번호가 올바르지 않습니다.");
    }
  };

  const goToMain = () => {
    setIsLoggedIn(true);
    navigate("/");
  };

  return (
    <div className={styles.screen}>
      <div className={styles.card}>
        {/* 첫 화면 */}
        {status === "init" && (
          <>
            <img src={character} alt="PORTIONY" className={styles.logo} />
            <p className={styles.slogan}>
              함께 사서, 함께 나누는
              <br /> 새로운 소비 문화
            </p>

            <button
              type="button"
              className={styles.kakaoButton}
              onClick={handleKakaoLogin}
            >
              카카오로 시작하기
            </button>

            <button
              type="button"
              className={styles.primaryButton}
              onClick={() => setStatus("form")}
            >
              이메일로 로그인
            </button>

            <p className={styles.footer}>
              첫 방문이신가요?{" "}
              <Link to="/signup" className={styles.link}>
                회원가입
              </Link>
            </p>
          </>
        )}

        {/* 로그인 폼 */}
        {status === "form" && (
          <>
            <div className={styles.header}>
              <button
                type="button"
                className={styles.backButton}
                onClick={() => setStatus("init")}
              >
                <img src={back} alt="뒤로가기" />
              </button>
              <h1 className={styles.title}>로그인</h1>
            </div>

            <img src={character} alt="PORTIONY" className={styles.smallLogo} />

            <form
              className={styles.form}
              onSubmit={(e) => {
                e.preventDefault();
                if (userEmail && userPassword) {
                  handleFinalLogin();
                }
              }}
            >
              <input
                type="email"
                className={styles.input}
                placeholder="이메일을 입력해주세요."
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
                required
              />
              <input
                type="password"
                className={styles.input}
                placeholder="비밀번호를 입력해주세요."
                value={userPassword}
                onChange={(e) => setUserPassword(e.target.value)}
                required
              />

              <button
                type="submit"
                className={styles.primaryButton}
                disabled={!userEmail || !userPassword}
              >
                로그인
              </button>
            </form>

            <p className={styles.footer}>
              비밀번호를 잊으셨나요?
              {/* 실제 기능 붙이면 Link로 바꿔 */}
            </p>
            <p className={styles.footer}>
              처음이신가요?{" "}
              <Link to="/signup" className={styles.link}>
                회원가입
              </Link>
            </p>
          </>
        )}

        {/* 로그인 완료 */}
        {status === "done" && (
          <>
            <img src={character} alt="PORTIONY" className={styles.logo} />
            <p className={styles.sloganDone}>
              로그인 완료되었습니다!
              <br />
              근처 소분을 바로 확인해보세요.
            </p>
            <button
              type="button"
              className={styles.primaryButton}
              onClick={goToMain}
            >
              메인 홈으로 가기
            </button>
          </>
        )}
      </div>
    </div>
  );
}

export default Login;
